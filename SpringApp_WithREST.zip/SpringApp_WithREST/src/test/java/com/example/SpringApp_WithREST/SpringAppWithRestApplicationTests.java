package com.example.SpringApp_WithREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAppWithRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
