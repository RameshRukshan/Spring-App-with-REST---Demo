package com.example.SpringApp_WithREST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAppWithRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAppWithRestApplication.class, args);
	}

}
